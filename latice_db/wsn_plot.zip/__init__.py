#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import division

import sys


#===============================================
# include functions here


#===============================================


def main(argv):
    #===========================================
    # My code here
    pass


if __name__ == "__main__":
    main(sys.argv)
